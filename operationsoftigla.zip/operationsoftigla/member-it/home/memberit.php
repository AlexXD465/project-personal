<?php 

session_start();

if (!isset($_SESSION['name'])) {
    header("Location: ../index.php");
    
}


?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Dashboard - Member IT</title>
  <meta name="viewport" content="width=device-width, initial-scale=1"><link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css'>
<link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css'><link rel="stylesheet" href="css/style.css">

</head>
<body onload="home();">
<!-- partial:index.partial.html -->
<div class="container-fluid">
  <div class="row">
    <!-- sidebar -->
    <div class="col-md-3 col-lg-2 px-0 position-fixed h-100 bg-white shadow-sm sidebar" id="sidebar">
      <h1 class="bi bi-exclude text-primary d-flex my-4 justify-content-center">  Tighitco SLP</h1>
      <div class="list-group rounded-0">
        <a href="../" class="list-group-item list-group-item-action border-0 d-flex align-items-center">
          <span class="bi bi-border-all"></span>
          <span class="ml-2">Dashboard</span>
        </a>
        <a href="#" onclick="employee();" class="list-group-item list-group-item-action border-0 align-items-center">
          <span class="bi bi-people-fill"></span>
          <span class="ml-2">Miembros</span>
        </a>

        <button class="list-group-item list-group-item-action border-0 d-flex justify-content-between align-items-center" data-toggle="collapse" data-target="#sale-collapse">
          <div>
            <span class="bi bi-list-check"></span>
            <span class="ml-2">Actividades - Reportes</span>
          </div>
          <span class="bi bi-chevron-down small"></span>
        </button>
        <div class="collapse" id="sale-collapse" data-parent="#sidebar">
          <div class="list-group">
            <a href="#" onclick="showtab(); showform();" class="list-group-item list-group-item-action border-0 pl-5"><i class="bi bi-grip-vertical"></i>Entregas</a>
            <a href="#" onclick="showtab2(); showform2();" class="list-group-item list-group-item-action border-0 pl-5"><i class="bi bi-grip-vertical"></i>Instalaciones</a>
          </div>
        </div>

        <button class="list-group-item list-group-item-action border-0 d-flex justify-content-between align-items-center" data-toggle="collapse" data-target="#purchase-collapse">
          <div>
            <span class="bi bi-save2-fill"></span>
            <span class="ml-2">Sugerencias</span>
          </div>
          <span class="bi bi-chevron-down small"></span>
        </button>
        <div class="collapse" id="purchase-collapse" data-parent="#sidebar">
          <div class="list-group">
            <a href="#" class="list-group-item list-group-item-action border-0 pl-5"><i class="bi bi-grip-vertical"></i>Mejora continua</a>
            <a href="#" class="list-group-item list-group-item-action border-0 pl-5"><i class="bi bi-grip-vertical"></i>Actividades diarias</a>
          </div>
        </div>
      </div>
    </div>
    <!-- overlay to close sidebar on small screens -->
    <div class="w-100 vh-100 position-fixed overlay d-none" id="sidebar-overlay"></div>
    <!-- note: in the layout margin auto is the key as sidebar is fixed -->
    <div class="col-md-9 col-lg-10 ml-md-auto px-0">
      <!-- top nav -->
      <nav class="w-100 d-flex px-4 py-2 mb-4 shadow-sm">
        <!-- close sidebar -->
        <button class="btn py-0 d-lg-none" id="open-sidebar">
          <span class="bi bi-list text-primary h3"></span>
        </button>
        <div class="dropdown ml-auto">
          <button class="btn py-0 d-flex align-items-center" id="logout-dropdown" data-toggle="dropdown" aria-expanded="false">
            <span class="bi bi-person-fill text-primary h4"></span>
            <p class="lead text-muted"> <?php echo($_SESSION["name"]); ?></p>
            <span class="bi bi-chevron-down ml-1 mb-2 small"></span>
          </button>
          <div class="dropdown-menu dropdown-menu-right border-0 shadow-sm" aria-labelledby="logout-dropdown">
            <a class="dropdown-item" href="#">Ajustes</a>
            <hr>
            <a class="dropdown-item" href="logout.php"><i class="bi bi-power"></i> Logout</a>
          </div>
        </div>
      </nav>
      <!-- main content -->
      <main class="container-fluid">
        <section class="row">
          <div class="col-md-6 col-lg-4">
            <!-- card -->
            <article class="p-4 rounded shadow-sm border-left
               mb-4">
              <a href="#" class="d-flex align-items-center">
                <span class="bi bi-file-earmark-check h5"></span>
                <h5 class="ml-2">Pendientes</h5>
              </a>
            </article>
          </div>
          <div class="col-md-6 col-lg-4">
            <article class="p-4 rounded shadow-sm border-left mb-4">
              <a href="#" class="d-flex align-items-center">
                <span class="bi bi-people-fill h5"></span>
                <h5 class="ml-2">Usuarios</h5>
              </a>
            </article>
          </div>
          <div class="col-md-6 col-lg-4">
            <article class="p-4 rounded shadow-sm border-left mb-4">
              <a href="#" class="d-flex align-items-center">
                <span class="bi bi-person-check-fill h5"></span>
                <h5 class="ml-2">Estatus - Usuario</h5>
              </a>
            </article>
          </div>
        </section>

        <div class="col-lg-12" id="respuesta"></div>
        
        <div id="home"></div>
        <div id="employee"></div>
        <div id="showform"></div>
        <br><br>
        <div id="showtab"></div>
        <div id="showform2"></div>
        <br><br>
        <div id="showtab2"></div>

      </main>
    </div>
  </div>
</div>
<!-- partial -->
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js'></script>
<script src='https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js'></script>
<script src='https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.min.js'></script><script  src="js/script.js"></script>
<script src="js/scripts.js"></script>
<script src="js/funciones.js"></script>
<script src="js/forms.js"></script>
<script src="js/tables.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery-3.5.1.min.js"></script>
<script src="js/popper.min.js.map"></script>
<script src="js/datatables-simple-demo.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>


</body>
</html>
