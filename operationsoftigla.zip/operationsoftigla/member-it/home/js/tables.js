function tabla1(){
    $("#tabla1").empty();
    $("#tabla2").empty();
 
    
    var url="tabs/tab-toner.php";
    
    $.ajax({  
        type: "POST",
        url:url,
        data:{},
        success: function(datos){
            $('#tabla1').html(datos);
        }
    });
    return false;
}

function tabla2(){
    $("#tabla2").empty();
    $("#tabla1").empty();
 
    
    var url="tabs/tab-instal.php";
    
    $.ajax({  
        type: "POST",
        url:url,
        data:{},
        success: function(datos){
            $('#tabla2').html(datos);
        }
    });
    return false;
}

function borrar(){
    $("#tabla2").empty();
    $("#tabla1").empty();
};