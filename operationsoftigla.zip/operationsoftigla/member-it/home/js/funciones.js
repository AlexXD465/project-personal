function home(){
    $("#home").empty();
    $("#showform").empty();
    $("#showtab").empty();
    $("#showform2").empty();
    $("#showtab2").empty();
    $("#employee").empty();

  var url="inicio.php"

  $.ajax({   
    type: "POST",
    url:url,
    data:{},
        beforeSend: function(){
            $("respuesta").show("swing");
            $("#respuesta").html("<div class='alert alert-primary' role='alert'><center><img src='img/load2.gif'>Procesando, espere por favor...</center></div>");
            
            

        },
    success: function(datos){
      $('#home').html(datos);
            $("#respuesta").empty();
    }
  });

}

function employee(){
    $("#employee").empty();
    $("#home").empty();
    $("#showform").empty();
    $("#showtab").empty();
    $("#showform2").empty();
    $("#showtab2").empty();

  var url="php/employee/employee-profiles.php"

  $.ajax({   
    type: "POST",
    url:url,
    data:{},
        beforeSend: function(){
            $("respuesta").show("swing");
            $("#respuesta").html("<div class='alert alert-primary' role='alert'><center><img src='img/load2.gif'>Procesando, espere por favor...</center></div>");
            
            

        },
    success: function(datos){
      $('#employee').html(datos);
            $("#respuesta").empty();
    }
  });

}


function showform(){
    $("#showform").empty();
    $("#showtab").empty();
    $("#home").empty();
    $("#showform2").empty();
    $("#showtab2").empty();
    $("#employee").empty();
    

  var url="php/forms/form1.php"

  $.ajax({   
    type: "POST",
    url:url,
    data:{},
        beforeSend: function(){
            $("respuesta").show("swing");
            $("#respuesta").html("<div class='alert alert-primary' role='alert'><center><img src='img/load2.gif'>Procesando, espere por favor...</center></div>");
            
            

        },
    success: function(datos){
      $('#showform').html(datos);
            $("#respuesta").empty();
    }
  });

}

function showtab(){
    $("#showtab").empty();
    $("#showform").empty();
    $("#home").empty();
    $("#showform2").empty();
    $("#showtab2").empty();
    $("#employee").empty();
    

  var url="php/tabs/tab-toner.php"

  $.ajax({   
    type: "POST",
    url:url,
    data:{},
        beforeSend: function(){
            $("respuesta").show("swing");
            $("#respuesta").html("<div class='alert alert-primary' role='alert'><center><img src='img/load2.gif'>Procesando, espere por favor...</center></div>");
            
            

        },
    success: function(datos){
      $('#showtab').html(datos);
            $("#respuesta").empty();
    }
  });

}

function showform2(){
    $("#showform2").empty();
    $("#showtab2").empty();
    $("#home").empty();
    $("#showtab").empty();
    $("#showform").empty();
    $("#employee").empty();

  var url="php/forms/form2.php"

  $.ajax({   
    type: "POST",
    url:url,
    data:{},
        beforeSend: function(){
            $("respuesta").show("swing");
            $("#respuesta").html("<div class='alert alert-primary' role='alert'><center><img src='img/load2.gif'>Procesando, espere por favor...</center></div>");
            
            

        },
    success: function(datos){
      $('#showform').html(datos);
            $("#respuesta").empty();
    }
  });

}

function showtab2(){
    $("#showtab2").empty();
    $("#showform2").empty();
    $("#home").empty();
    $("#showtab").empty();
    $("#showform").empty();
    $("#employee").empty();

  var url="php/tabs/tab-instal.php"

  $.ajax({   
    type: "POST",
    url:url,
    data:{},
        beforeSend: function(){
            $("respuesta").show("swing");
            $("#respuesta").html("<div class='alert alert-primary' role='alert'><center><img src='img/load2.gif'>Procesando, espere por favor...</center></div>");
            
            

        },
    success: function(datos){
      $('#showtab').html(datos);
            $("#respuesta").empty();
    }
  });

}



