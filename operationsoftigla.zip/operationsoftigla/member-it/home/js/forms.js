function form1(){
    $("#form1").empty();
    $("#form2").empty();
    $("#form3").empty();
    $("#form4").empty();
    $("#inicio").empty();
    $("#tabla1").empty();
    $("#tabla2").empty();

  var url="forms/form1.php"

  $.ajax({   
    type: "POST",
    url:url,
    data:{},
        beforeSend: function(){
            $("respuesta").show("swing");
            $("#respuesta").html("<div class='alert alert-primary' role='alert'><center><img src='img/load2.gif'>Procesando, espere por favor...</center></div>");
            
            

        },
    success: function(datos){
      $('#form1').html(datos);
            $("#respuesta").empty();
    }
  });

}

function enviardatos(fol_mov,fecha_etga,clave,n_equipo,ubicacion,n_serie,n_solicitud,n_seiton,nom_it){
    var parametros = {
        "fol_mov" : fol_mov,
        "fecha_etga" : fecha_etga,
        "clave" : clave,
        "n_equipo" : n_equipo,
        "ubicacion" : ubicacion,
        "n_serie" : n_serie,
        "n_solicitud" : n_solicitud,
        "n_seiton" : n_seiton,
        "nom_it" : nom_it,
         
    };
    $.ajax({
        data: parametros,
        url: 'forms/formdatos.php',
        type: 'POST',
        beforeSend: function(){
            $("#respuesta").show("swing");
            $("#respuesta").html("<div class='alert alert-primary' role='alert'><center><img src='img/load2.gif'>Procesando, espere por favor...</center></div>");

        },
        success:  function(response){
            document.getElementById('formulario').reset();
            setTimeout(function() {
                $("#respuesta").fadeOut(3500);
                $("#respuesta").html(response);
            },2000);
        }
    });
}

function form2(){
    $("#form2").empty();
    $("#form1").empty();
    $("#form3").empty();
    $("#form4").empty();
    $("#inicio").empty();
    $("#tabla1").empty();
    $("#tabla2").empty();

  var url="forms/form2.php"

  $.ajax({   
    type: "POST",
    url:url,
    data:{},
        beforeSend: function(){
            $("respuesta").show("swing");
            $("#respuesta").html("<div class='alert alert-primary' role='alert'><center><img src='img/load2.gif'>Procesando, espere por favor...</center></div>");
            
            

        },
    success: function(datos){
      $('#form2').html(datos);
            $("#respuesta").empty();
    }
  });

}

function enviardatos2(fechainstalacion, maqinstal, numserie, respon){
    var parametros = {
        "fechainstalacion" : fechainstalacion,
        "maqinstal" : maqinstal,
        "numserie" : numserie,
        "respon" : respon,
         
    };
    $.ajax({
        data: parametros,
        url: 'forms/enviardatos.php',
        type: 'POST',
        beforeSend: function(){
            $("#respuesta").show("swing");
            $("#respuesta").html("<div class='alert alert-primary' role='alert'><center><img src='img/load2.gif'>Procesando, espere por favor...</center></div>");

        },
        success:  function(response){
            document.getElementById('form').reset();
            setTimeout(function() {
                $("#respuesta").fadeOut(3500);
                $("#respuesta").html(response);
            },2000);
        }
    });
}

function form3(){
    $("#form3").empty();
    $("#form1").empty();
    $("#form2").empty();
    $("#form4").empty();
    $("#inicio").empty();


  var url="forms/form3.php"

  $.ajax({   
    type: "POST",
    url:url,
    data:{},
        beforeSend: function(){
            $("respuesta").show("swing");
            $("#respuesta").html("<div class='alert alert-primary' role='alert'><center><img src='img/load2.gif'>Procesando, espere por favor...</center></div>");
            
            

        },
    success: function(datos){
      $('#form3').html(datos);
            $("#respuesta").empty();
    }
  });

}

function form4(){
    $("#form4").empty();
    $("#form1").empty();
    $("#form2").empty();
    $("#form3").empty();
    $("#inicio").empty();


  var url="forms/form4.php"

  $.ajax({   
    type: "POST",
    url:url,
    data:{},
        beforeSend: function(){
            $("respuesta").show("swing");
            $("#respuesta").html("<div class='alert alert-primary' role='alert'><center><img src='img/load2.gif'>Procesando, espere por favor...</center></div>");
            
            

        },
    success: function(datos){
      $('#form4').html(datos);
            $("#respuesta").empty();
    }
  });

}

function enviaractividades(){
    var parametros = {
        "fol_mov" : fol_mov,
        "fecha_etga" : fecha_etga,
        "clave" : clave,
        "n_equipo" : n_equipo,
        "ubicacion" : ubicacion,
        "n_serie" : n_serie,
        "n_solicitud" : n_solicitud,
        "n_seiton" : n_seiton,
        "nom_it" : nom_it,
         
    };
    $.ajax({
        data: parametros,
        url: 'forms/formdatos.php',
        type: 'POST',
        beforeSend: function(){
            $("#respuesta").show("swing");
            $("#respuesta").html("<div class='alert alert-primary' role='alert'><center><img src='img/load2.gif'>Procesando, espere por favor...</center></div>");

        },
        success:  function(response){
            document.getElementById('formulario').reset();
            setTimeout(function() {
                $("#respuesta").fadeOut(3500);
                $("#respuesta").html(response);
            },2000);
        }
    });
}