<?php 

session_start();
?>

<div class="jumbotron jumbotron-fluid rounded bg-white border-0 shadow-sm border-left px-4">
  <div class="container">
    <h1 class="display-4 mb-2 text-primary"><i class="bi bi-person-circle"></i> Bienvenido</h1> 
    <p class="lead text-muted">Usuario: <?php echo($_SESSION["name"]); ?>.</p>
  </div>
</div>