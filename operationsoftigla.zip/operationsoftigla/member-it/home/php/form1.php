<?php sleep(1) ?>

<div class="card">
    <div class="card-header">
        <i class="bi bi-person-plus-fill me-1"></i> Toner Seiton (En caso de ser entrega)
    </div>
    <div class="card-body">
        <blockquote class="blockquote mb-0">

            <form id="formulario">
                <div class="form-row">
                    <div class="form-group col-md-4">
                        <label for="inputEmail4"><b>Folio Mov.</b></label>
                        <input type="text" class="form-control" id="fol_mov" placeholder="Folio">
                    </div>
                    <div class="form-group col-md-4">
                        <label for="inputPassword4"><b>Fecha de entrega</b></label>
                        <input type="datetime-local" class="form-control" id="fecha_etga">
                    </div>
                    <div class="form-group col-md-4">
                        <label for="inputPassword4"><b>Clave</b></label>
                        <input type="text" class="form-control" id="clave" placeholder="Clave">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group col-md-4">
                        <label for="inputEmail4"><b>Numero de equipo</b></label>
                        <input type="text" class="form-control" id="n_equipo" placeholder="Numero de equipo">
                    </div>
                    <div class="form-group col-md-4">
                        <label for="inputState"><b>Ubicacion</b></label>
                        <select id="ubicacion" class="form-control">
                            <option selected> </option>
                            <option>Clinica Calidad</option>
                            <option>Recursos Humanos</option>
                            <option>Embarques</option>
                            <option>EmbLider</option>
                            <option>Oficina Produccion</option>
                            <option>Calidad</option>
                            <option>Do-Reclutamiento</option>
                            <option>Produccion Regular</option>
                            <option>Almacen</option>
                            <option>Metalicos Tenneco</option>
                            <option>MSP</option>
                            <option>CO-WORKING</option>
                            <option>Inspeccion Recibo</option>
                            <option>Asistente Produccion</option>
                            <option>Gerencia Finanzas</option>
                        </select>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="inputPassword4"><b>Numero Serie</b></label>
                        <input type="text" class="form-control" id="n_serie" placeholder="Numero de serie">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group col-md-4">
                        <label for="inputEmail4"><b>Numero Solicitud</b></label>
                        <input type="text" class="form-control" id="n_solicitud" placeholder="Numero de solicitud">
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label for="inputEmail4"><b>Entrega</b></label>
                            <input type="text" class="form-control" id="n_seiton" placeholder="Entrego">
                        </div>
                        <div class="form-group col-md-4">
                            <label for="inputState"><b>Miembro IT</b></label>
                            <select id="nom_it" class="form-control">
                                <option selected> </option>
                                <option>Angel Suarez</option>
                                <option>Alexis Zarate</option>
                                <option>Jorge Ibarra</option>
                                <option>Guillermo Rocha</option>
                                <option>Marcos Torres</option>.
                                <option>Laura Herrera</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputPassword4"><b>¿Los datos han sido llenados correctamente?</b></label>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="gridCheck">
                            <label class="form-check-label" for="gridCheck">
                                Si
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="gridCheck">
                            <label class="form-check-label" for="gridCheck">
                                No
                            </label>
                        </div>

                    </div>
                    <div class="col-12">
                        <div class="d-grid gap-2 col-8 mx-auto">
                            <button type="submit" class="btn btn-primary" id="btnenviar">Enviar</button>
                        </div>
                    </div>
                </div>

            </form>
        </blockquote>
    </div>
</div>

<script>
    $("#btnenviar").click(function(event) {
        enviardatos($('#fol_mov').val(), $('#fecha_etga').val(), $('#clave').val(), $('#n_equipo').val(), $('#ubicacion').val(), $('#n_serie').val(), $('#n_solicitud').val(), $('#n_seiton').val(), $('#nom_it').val());


        return false;

    });

</script>
