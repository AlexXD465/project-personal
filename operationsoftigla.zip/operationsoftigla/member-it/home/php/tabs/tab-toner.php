<?php sleep(1) ?>
                           

                           <div class="card mb-4">
                            <div class="card-header">
                                <i class="bi bi-table me-1"></i>
                                Registros de Toner
                            </div>
                        <div class="card-body">
                            <table class="table table-hover" id="datatablesSimple">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Folio Mov</th>
                                    <th scope="col">Fecha entrega</th>
                                    <th scope="col">Clave</th>
                                    <th scope="col">N. Equipo</th>
                                    <th scope="col">Ubicacion</th>
                                    <th scope="col">N. Serie</th>
                                    <th scope="col">N. Solicitud</th>
                                    <th scope="col">Entrego</th>
                                    <th scope="col">Recibio</th>

                                </tr>
                            </thead>
                                <?php
                                include("../../DB/conectar.phtml");
                                $conexion = Conectarse();
                                mysqli_query($conexion,"SET CHARACTER SET 'utf8'");
                                mysqli_query($conexion,"SET SESSION collation_connection ='utf8_unicode_ci'");
                                $query = "SELECT * FROM xerox_admin";
                                $result = $conexion->query($query);
                                $numfilas = $result->num_rows;
                                for($x=0;$x<$numfilas;$x++) {
                                    $fila = $result->fetch_object();
                                    echo "<tr>";
                                    echo "<th scope='row'>".$fila->id."</th>";
                                    echo "<td>".$fila->fol_mov."</td>";
                                    echo "<td>".$fila->fecha_etga."</td>";
                                    echo "<td>".$fila->clave."</td>";
                                    echo "<td>".$fila->n_equipo."</td>";
                                    echo "<td>".$fila->ubicacion."</td>";
                                    echo "<td>".$fila->n_serie."</td>";
                                    echo "<td>".$fila->n_solicitud."</td>";
                                    echo "<td>".$fila->n_seiton."</td>";
                                    echo "<td>".$fila->nom_it."</td>";

                                echo "</tr>";
                                }

                                $conexion->close();
                                ?>
                            <tbody>

                            </tbody>
                        </table>
                        </div>
                    </div>
                    
                   <script>
$(document).ready(function() {
    $('#example').DataTable({ 
        
        });; 
</script>