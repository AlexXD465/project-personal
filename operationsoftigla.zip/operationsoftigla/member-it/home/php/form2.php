<?php sleep(1) ?>

<div class="card">
  <div class="card-header">
    <i class="bi bi-person-dash-fill me-1"></i> Instalacion de toner
  </div>
  <div class="card-body">
    <blockquote class="blockquote mb-0">
<form id="form">
  <div class="form-row">
    <div class="form-group col-md-4">
      <label for="inputPassword4"><b>Fecha de Instalacion</b></label>
      <input type="datetime-local" class="form-control" id="fechainstalacion">
    </div>
        <div class="form-group col-md-4">
      <label for="inputState"><b>Maquina Instalada</b></label>
      <select id="maqinstal" class="form-control">
        <option selected> </option>
        <option>Clinica Calidad</option>
        <option>Recursos Humanos</option>
        <option>Embarques</option>
        <option>EmbLider</option>
        <option>Oficina Produccion</option>
        <option>Calidad</option>
        <option>Do-Reclutamiento</option>
        <option>Produccion Regular</option>
        <option>Almacen</option>
        <option>Metalicos Tenneco</option>
        <option>MSP</option>
        <option>CO-WORKING</option>
        <option>Inspeccion Recibo</option>
        <option>Asistente Produccion</option>
        <option>Gerencia Finanzas</option>
      </select>
    </div>
    <div class="form-group col-md-4">
      <label for="inputPassword4"><b>Numero Serie</b></label>
      <input type="text" class="form-control" id="numserie" placeholder="Numero de serie">
    </div>
  </div>

  <div class="form-row">
    <div class="form-group col-md-4">
      <label for="inputState"><b>Miembro IT</b></label>
      <select id="respon" class="form-control">
        <option selected> </option>
        <option>Angel Suarez</option>
        <option>Alexis Zarate</option>
        <option>Jorge Ibarra</option>
        <option>Guillermo Rocha</option>
        <option>Marcos Torres</option>.
        <option>Laura Herrera</option>
      </select>
    </div>
  </div>
  <div class="row">
  <div class="form-group">
    <label for="inputPassword4"><b>¿Los datos han sido llenados correctamente?</b></label>
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Si
      </label>
    </div>
        <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        No
      </label>
    </div>

  </div>
  </div>
  
  <div class="col-12">
    <div class="d-grid gap-2 col-8 mx-auto">
    <button type="submit" class="btn btn-primary" id="btnenviar2">Enviar</button>
  </div>
    </div>
</form>

    </blockquote>
  </div>
</div>

<script>
  $("#btnenviar2").click(function(event) {
        enviardatos2($('#fechainstalacion').val(),$('#maqinstal').val(),$('#numserie').val(),$('#respon').val());
        
        
    return false;
    
  });       
</script>