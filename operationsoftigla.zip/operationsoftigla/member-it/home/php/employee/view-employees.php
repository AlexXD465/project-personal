<?php sleep(1); ?>
<div class="card mb-4">
                         <div class="card-header">
                                <i class="bi bi-person-lines-fill me-2"></i>
                                 Usarios Facilitys
                            </div>
                        <div class="card-body">
                            <table class="table table-hover" id="datatablesSimple">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Usuario</th>
                                    <th scope="col">Nombre</th>
                                    <th scope="col">Action</th>


                                </tr>
                            </thead>
                                <?php
                                include("../../DB/db.php");
                                $conn = Conectarse();
                                mysqli_query($conn,"SET CHARACTER SET 'utf8'");
                                mysqli_query($conn,"SET SESSION collation_connection ='utf8_unicode_ci'");
                                $query = "SELECT * FROM facility_user";
                                $result = $conn->query($query);
                                $numfilas = $result->num_rows;
                                for($x=0;$x<$numfilas;$x++) {
                                    $fila = $result->fetch_object();
                                    echo "<tr>";
                                    echo "<th scope='row'>".$fila->id."</th>";
                                    echo "<td>".$fila->username."</td>";
                                    echo "<td>".$fila->name."</td>";
                                    echo "<td><button type='button' class='btn btn-primary btn-sm'>Nuevo</button></td>";
                                    echo "<td><button type='button' class='btn btn-primary btn-sm'>Editar</button></td>";
                                    echo "<td><button type='button' class='btn btn-primary btn-sm'>Eliminar</button></td>";


                                echo "</tr>";
                                }

                                $conn->close();
                                ?>

                            <tbody>


                            </tbody>
                        </table>
                        </div>
</div>