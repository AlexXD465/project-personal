<?php 

session_start();
?>
<?php sleep(1) ?>

<div class="jumbotron jumbotron-fluid rounded bg-white border-0 shadow-sm border-left px-4">
  <div class="container">
    <h1 class="display-4 mb-2 text-primary"><i class="bi bi-people-fill"></i> Usuarios</h1> 
    <p class="lead text-muted">Total de usuarios:
      <?php
      include("../../DB/config.php");
      $conn = mysqli_connect($server, $user, $pass, $database);
      $sql = "SELECT * FROM facility_user";
      if ($stmt = $conn->prepare($sql)) {
        $stmt->execute();
        $stmt->store_result();
        printf("%d. \n", $stmt->num_rows);
        }
?>

    </p>
  </div>
</div>

<div class="jumbotron jumbotron-fluid rounded bg-white border-0 shadow-sm border-left px-4">
  <div class="container">
    <h1 class="display-4 mb-2 text-primary"><i class="bi bi-person-circle"></i> Administrador - employees</h1> 
    <p class="lead text-muted">Usuarios: 
      <button type="button" class="btn btn-primary btn-sm" onclick="view();"><i class="bi bi-eye-fill"></i> Ver</button>
      <button type="button" class="btn btn-primary btn-sm" onclick="ocultar();"><i class="bi bi-eye-slash-fill"></i> Ocultar</button>

    </p>
    <hr>
    <div id="view"></div>
    <div id="loading"></div>
    
  </div>
</div>
<script>

function view(){
    $("#view").empty();

  var url="php/employee/view-employees.php"

  $.ajax({   
    type: "POST",
    url:url,
    data:{},
        beforeSend: function(){
            $("loading").show("swing");
            $("#loading").html("<div class='alert alert-primary' role='alert'><center><img src='img/load2.gif'>Procesando, espere por favor...</center></div>");
            
            

        },
    success: function(datos){
      $('#view').html(datos);
            $("#loading").empty();
    }
  });

}

function ocultar(){
    $("#view").empty();

}

</script>