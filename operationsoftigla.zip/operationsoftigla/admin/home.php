<?php 

session_start();

if (!isset($_SESSION['name'])) {
    header("Location: index.php");
    
}


?>


<h4>Hola User</h4>