
<?php
$conn = new mysqli('localhost', 'root','' , 'operatigla');
$sql = "SELECT * FROM users";
if ($result=mysqli_query($conn,$sql)) {
    $rowcount=mysqli_num_rows($result);
    echo "Total de usuarios: ".$rowcount; 
}
?>