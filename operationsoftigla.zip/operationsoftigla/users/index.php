<?php 

include 'config.php';

session_start();

error_reporting(0);

if (isset($_SESSION['name'])) {
    header("Location: home/user.php");
}

if (isset($_POST['submit'])) {
	$username = $_POST['username'];
	$password = ($_POST['password']);

	$sql = "SELECT * FROM facility_user WHERE username='$username' AND password='$password'";
	$result = mysqli_query($conn, $sql);
	if ($result->num_rows > 0) {
		$row = mysqli_fetch_assoc($result);
		$_SESSION['name'] = $row['name'];
		header("Location: home/user.php");
	} else {
		echo "<script>alert('Woops! Email or Password is Wrong.')</script>";
	}
}

?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>facility</title>
  <link href="https://fonts.googleapis.com/css?family=Asap" rel="stylesheet"><link rel="stylesheet" href="css/style.css">

</head>
<body>

<!-- partial:index.partial.html -->
<form class="login" method="POST" >
    <center><b>Inicia Sesion</b></center>
  <input type="text" name="username" id="username" placeholder="Username" value="<?php echo $_POST['username']; ?>" required>
  <input type="password" name="password" id="password" placeholder="Password" value="<?php echo $_POST['password']; ?>" required>
  <button name="submit" id="submit"  value="Submit" >Login</button>
  <br><br>
  <hr>
 <a href="../" class="btn" style="color:#000000">Click para regresar</a>
</form>

</body>
</html>
