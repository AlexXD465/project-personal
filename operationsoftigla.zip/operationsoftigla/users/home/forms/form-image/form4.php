<?php sleep(2) ?>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="js/script.js"></script>

<div class="card">
  <div class="card-header">
    <i class="fas fa-user me-1"></i> Reporte de Acrtividades
  </div>
  <div class="card-body">
    <blockquote class="blockquote mb-0">
<form id="form">
  <div class="form-row">
    <div class="form-group col-md-4">
      <label for="inputPassword4"><b>Fecha Actividad</b></label>
      <input type="date" class="form-control" id="fechainstalacion">
    </div>
        <div class="form-group col-md-4">
      <label for="inputState"><b>Area</b></label>
      <select id="maqinstal" class="form-control">
        <option selected> </option>
        <option>Recursos Humanos</option>
        <option>Embarques</option>
        <option>Oficina Produccion</option>
        <option>Calidad</option>
        <option>Do-Reclutamiento</option>
        <option>Produccion Regular</option>
        <option>Almacen</option>
        <option>Metalicos Tenneco</option>
        <option>MSP</option>
        <option>CO-WORKING</option>
        <option>Inspeccion Recibo</option>
        <option>Asistente Produccion</option>
        <option>Finanzas</option>
      </select>
    </div>

    <div class="form-group col-md-4">
      <label for="inputState"><b>Miembro IT</b></label>
      <select id="respon" class="form-control">
        <option selected> </option>
        <option>Angel Suarez</option>
        <option>Alexis Zarate</option>
        <option>Jorge Ibarra</option>
        <option>Guillermo Rocha</option>
        <option>Marcos Torres</option>.
        <option>Laura Herrera</option>
      </select>
    </div>
    </div>
  <div class="col-12">
    <div class="d-grid gap-2 col-8 mx-auto">
    <button type="submit" class="btn btn-primary" id="btnenviar2">Enviar</button>
  </div>
    </div>
</form>
    </blockquote>
  </div>

  
</div>




<script>
  $("#btnenviar4").click(function(event) {
        enviardatos2($('#fechainstalacion').val(),$('#maqinstal').val(),$('#numserie').val(),$('#respon').val());
        
        
    return false;
    
  });       
</script>