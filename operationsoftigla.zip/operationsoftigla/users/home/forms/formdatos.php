<?php
    $fol_mov = $_POST['fol_mov'];
    $fecha_etga = $_POST['fecha_etga'];
    $clave = $_POST['clave'];
    $n_equipo = $_POST['n_equipo'];
    $ubicacion = $_POST['ubicacion'];
    $n_serie = $_POST['n_serie'];
    $n_solicitud = $_POST['n_solicitud'];
    $n_seiton = $_POST['n_seiton'];
    $nom_it = $_POST['nom_it'];
    
    include("../DB/conectar.phtml");
    $conexion = Conectarse();   
    mysqli_query($conexion,"SET CHARACTER SET 'utf8'");
    mysqli_query($conexion,"SET SESSION collation_connection ='utf8_unicode_ci'");

    if ($conexion->connect_error){       
        die('Error de Conexión (' . $conexion->connect_errno . ') '. $conexion->connect_error);       
    }else{
        $save = "INSERT INTO xerox_admin(fol_mov,fecha_etga,clave,n_equipo,ubicacion,n_serie,n_solicitud,n_seiton,nom_it) VALUES('$fol_mov','$fecha_etga','$clave','$n_equipo','$ubicacion','$n_serie','$n_solicitud','$n_seiton',
            '$nom_it')";
        $conexion->query($save);
        mysqli_close($conexion);
        echo '<div class="alert alert-success" role="alert">';
        echo '<img src="img/load2.gif"> ¡Tu datos fueron enviados correctamente!';
        echo '</div>';
    }

?>
