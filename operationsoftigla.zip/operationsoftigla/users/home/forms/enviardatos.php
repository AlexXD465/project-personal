<?php
    $fechainstalacion = $_POST['fechainstalacion'];
    $maqinstal = $_POST['maqinstal'];
    $numserie = $_POST['numserie'];
    $respon = $_POST['respon'];

    
    include("../DB/conectar.phtml");
    $conexion = Conectarse();   
    mysqli_query($conexion,"SET CHARACTER SET 'utf8'");
    mysqli_query($conexion,"SET SESSION collation_connection ='utf8_unicode_ci'");

    if ($conexion->connect_error){       
        die('Error de Conexión (' . $conexion->connect_errno . ') '. $conexion->connect_error);       
    }else{
        $save = "INSERT INTO instal_xerox(fecha_instalacion, maq_instalada, n_serie, it_member) VALUES('$fechainstalacion','$maqinstal','$numserie','$respon')";
        $conexion->query($save);
        mysqli_close($conexion);
        echo '<div class="alert alert-success" role="alert">';
        echo '<img src="img/load2.gif"> ¡Tu datos fueron enviados correctamente!';
        echo '</div>';
    }

?>