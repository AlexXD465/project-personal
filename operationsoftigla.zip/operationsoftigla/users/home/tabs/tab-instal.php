
                           
<div class="card mb-4">
                         <div class="card-header">
                                <i class="fas fa-table me-2"></i>
                                Registros de Instalaciones
                            </div>
                        <div class="card-body">
                            <table class="table table-hover" id="datatablesSimple">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Fecha instalacion</th>
                                    <th scope="col">Equipo</th>
                                    <th scope="col">N. Serie</th>
                                    <th scope="col">Miembro IT</th>


                                </tr>
                            </thead>
                                <?php
                                include("../DB/conectar.phtml");
                                $conn = Conectarse();
                                mysqli_query($conn,"SET CHARACTER SET 'utf8'");
                                mysqli_query($conn,"SET SESSION collation_connection ='utf8_unicode_ci'");
                                $query = "SELECT * FROM instal_xerox";
                                $result = $conn->query($query);
                                $numfilas = $result->num_rows;
                                for($x=0;$x<$numfilas;$x++) {
                                    $fila = $result->fetch_object();
                                    echo "<tr>";
                                    echo "<th scope='row'>".$fila->id."</th>";
                                    echo "<td>".$fila->fecha_instalacion."</td>";
                                    echo "<td>".$fila->maq_instalada."</td>";
                                    echo "<td>".$fila->n_serie."</td>";
                                    echo "<td>".$fila->it_member."</td>";


                                echo "</tr>";
                                }

                                $conn->close();
                                ?>
                            <tbody>

                            </tbody>
                        </table>
                        </div>
</div>  
                    
                   <script>
$(document).ready(function() {
    $('#example').DataTable({ 
        
        });; 
</script>