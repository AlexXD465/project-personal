function inicio(){
    $("#inicio").empty();
    $("#form1").empty();
    $("#form2").empty();
    $("#form3").empty();
    $("#form4").empty();

  var url="inicio.php"

  $.ajax({   
    type: "POST",
    url:url,
    data:{},
        beforeSend: function(){
            $("respuesta").show("swing");
            $("#respuesta").html("<div class='alert alert-primary' role='alert'><center><img src='img/load2.gif'>Procesando, espere por favor...</center></div>");
            
            

        },
    success: function(datos){
      $('#inicio').html(datos);
            $("#respuesta").empty();
    }
  });

}