 <?php sleep (2); ?>

                    
                       <div class="row">
                       <div class="col-8">
                        
        
        <div class="alert alert-info d-flex align-items-center" role="alert">
  <div class="col-3">
   <img src="img/logo.png" style="max-width: 200px; max-height: 100px;"> 
  </div>
  <div class="col-6">
      <h3><strong> RECUERDA LLENAR TODO CORRECTAMENTE.</strong></h3>
      <hr>
  </div>
</div>
       <div class="alert alert-info" role="alert">
  <h4 class="alert-heading"><b>A TRABAJAR!</b></h4>
  <b>Todos los datos proporcionados dentro de la plataforma deben ser exclusivamente ingresador con cuidado ya que cada activo dentro de la empresa es importante para poder continuar con las labores de todos los dias.</b>
  <hr>
  <p class="mb-0">Si notas anormalidades en la pagina, favor de contactar al soporte de IT.</p>
</div>
    </div>    
   
<div class="col-4">
 <div class="card mb-3" style="max-width: 800px;">
  <div class="row g-0">
    <div class="col-md-4">
     <img src="img/tonerxerox.jpg" class="img-fluid rounded-start" alt="..." style="max-width: 300px; height: 200px; ">
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <center><h3 class="card-title"><b>Toner Xerox</b></h3></center>
        <hr>
      </div>
    </div>
  </div>
</div>
</div>
 </div>
<div class="row">
 <div class="d-grid gap-2 col-6 mx-auto">
  <button class="btn btn-primary" type="button" onclick="tabla1();tabla2();">Ver tablas</button>
</div>
<div class="d-grid gap-2 col-6 mx-auto">
  <button class="btn btn-primary" type="button" onclick="borrar();">Ocultar tablas</button>
</div>
</div>