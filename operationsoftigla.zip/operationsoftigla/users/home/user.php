<?php 

session_start();

if (!isset($_SESSION['name'])) {
    header("Location: ../index.php");
    
}


?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Facility - Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css'>
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css'><link rel="stylesheet" href="./style.css">

</head>
<body onload="inicio();">
<!-- partial:index.partial.html -->
<body class="sidebar-is-reduced">
  <header class="l-header">
    <div class="l-header__inner clearfix">
      <div class="c-header-icon js-hamburger">
        <div class="hamburger-toggle"><span class="bar-top"></span><span class="bar-mid"></span><span class="bar-bot"></span></div>
      </div>
      <div class="c-header-icon has-dropdown"><span class="c-badge c-badge--red c-badge--header-icon animated swing">1</span><i class="fa fa-bell"></i>
        <div class="c-dropdown c-dropdown--notifications">
          <div class="c-dropdown__header"></div>
          <div class="c-dropdown__content"></div>
        </div>
      </div>
      <div class="c-search">
        <input class="c-search__input u-input" placeholder="Search..." type="text"/>
      </div>
      <div class="header-icons-group">
        <div class="c-header-icon basket"><span class="c-badge c-badge--blue c-badge--header-icon animated swing">1</span><i class="fa fa-shopping-basket"></i></div>
        <div class="c-header-icon logout" ><a href="logout.php"><i class="fa fa-power-off"></i></a></div>
      </div>
    </div>
  </header>
  <div class="l-sidebar">
    <div class="logo">
      <div class="logo__txt">Tighitco</div>
    </div>
    <div class="l-sidebar__content">
      <nav class="c-menu js-menu">
        <ul class="u-list">
          <li class="c-menu__item is-active" data-toggle="tooltip" title="Home">
            <div class="c-menu__item__inner" onclick="inicio();"><i class="fa fa-home"></i>
              <div class="c-menu-item__title" onclick="inicio();"><span>Home</span></div>
            </div>
          </li>
          <li class="c-menu__item has-submenu" data-toggle="tooltip" title="Formularios">
            <div class="c-menu__item__inner" onclick="form1();form2();"><i class="fa fa-th-large"></i>
              <div class="c-menu-item__title" onclick="form1();form2();"><span>Formularios</span></div>
              <div class="c-menu-item__expand js-expand-submenu">
                </div>
              </div>
          </li>
          <li class="c-menu__item has-submenu" data-toggle="tooltip" title="Statistics">
            <div class="c-menu__item__inner"><i class="far fa-folder"></i>
              <div class="c-menu-item__title"><span>Statistics</span></div>
            </div>
          </li>
          <li class="c-menu__item has-submenu" data-toggle="tooltip" title="Usuario">
            <div class="c-menu__item__inner"><i class="fa fa-user"></i>
              <div class="c-menu-item__title"><span>Usuario</span></div>
            </div>
          </li>
          <li class="c-menu__item has-submenu" data-toggle="tooltip" title="Settings">
            <div class="c-menu__item__inner"><i class="fa fa-cogs"></i>
              <div class="c-menu-item__title"><span>Settings</span></div>
            </div>
          </li>
        </ul>
      </nav>
    </div>
  </div>
</body>
<main class="l-main">
  <div class="content-wrapper content-wrapper--with-bg">
    <h1 class="page-title">Dashboard - Facility</h1>
    <div class="page-content">
     <div class="row">
                       <div class="col-lg-6" id="espacio1">
                           
                            <h1 class="mt-4">Bienvenido <span class="badge badge-primary"> <b style="text-transform: capitalize;" ><?php echo($_SESSION["name"]); ?> </b> </span></h1> 
 
                       </div>
                       
                        <div class="col-lg-6" id="respuesta"></div>
                    </div>
                      <div id="inicio"></div>
                     </div>
                 <br><br>
                  
                   <div class="row">
                       <div id="tabla1"></div>
                       <div id="tabla2"></div>
                       
                   </div>
                    <div class="row">
                        <div class="col-xl-12" id="form1"></div>
                    </div>
                    <br><br>
                    <div class="row">
                        <div class="col-xl-12" id="form2"></div>
                    </div>
                   <div class="row">
                        <div class="col-xl-12" id="form3"></div>
                    </div>
                    <div class="row">
                        <div class="col-xl-12" id="form4"></div>
                    </div>
                    <br><br>
  </div>
</main>




        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
        <script src="js/scripts.js"></script>
        <script src="js/funciones.js"></script>
        <script src="js/forms.js"></script>
        <script src="js/tables.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery-3.5.1.min.js"></script>
        <script src="js/popper.min.js.map"></script>
        <script src="js/datatables-simple-demo.js"></script>
        <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js'></script>
<script src='https://use.fontawesome.com/releases/v5.0.8/js/all.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js'></script><script  src="./script.js"></script>
        
       

    </body>
</html>